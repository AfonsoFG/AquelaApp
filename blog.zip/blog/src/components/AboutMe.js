import React, { Fragment } from 'react'

const AboutMe = ({ postData }) => 
      <Fragment>
        <div className='about-me-section'>
          <h4>About Me</h4>
          <p>Morbi porta eros ex, eget condimentum dolor vehicula quis. Fusce pellentesque facilisis sapien, vel pulvinar diam tempor vitae. Donec at urna in metus luctus dapibus eu vel lectus. In luctus egestas urna, ut aliquam elit lacinia at. Morbi dolor massa, vehicula sit amet lectus vel, sodales ultrices nunc. Nullam finibus gravida lorem non consequat</p>
          <p>Morbi porta eros ex, eget condimentum dolor vehicula quis. Fusce pellentesque facilisis sapien, vel pulvinar diam tempor vitae. Donec at urna in metus luctus dapibus eu vel lectus. In luctus egestas urna, ut aliquam elit lacinia at. Morbi dolor massa, vehicula sit amet lectus vel, sodales ultrices nunc. Nullam finibus gravida lorem non consequat</p>
          <p>Morbi porta eros ex, eget condimentum dolor vehicula quis. Fusce pellentesque facilisis sapien, vel pulvinar diam tempor vitae. Donec at urna in metus luctus dapibus eu vel lectus. In luctus egestas urna, ut aliquam elit lacinia at. Morbi dolor massa, vehicula sit amet lectus vel, sodales ultrices nunc. Nullam finibus gravida lorem non consequat</p>
        </div>
      </Fragment>

export default AboutMe