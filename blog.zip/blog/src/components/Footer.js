import React from 'react'

const Footer = () => <div className='blog-footer'></div>

export default Footer