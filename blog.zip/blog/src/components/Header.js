import React from 'react'

const Header = () => 
        <div className='blog-header'>
          <h1>Blog</h1>
        </div>

export default Header