import React from 'react';
import { Main } from './components'
import './App.css';

function App() {
  return (
    <div className="app">
      <Main />
    </div>
  );
}

export default App;
